Mickaël FARDILHA & Dorian COFFINET

Environnement : JAVA 1.7

Compiler le projet avec ANT :
	- La commande "ant" compile les classes et génère le JAR exécutatble sous ./build/jar
	- La commande "ant comile" compile les classes
	- La commande "ant clean" détruit les fichiers compilés
	
Lancer l'application :
	- Se rendre dans le repertoire contenant le jar (cd [repertoire]/build/jar)
	- Lancer la commande "java -jar clicMax.jar"
